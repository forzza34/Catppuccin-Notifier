async function init() {
  const body = document.getElementById("body");
  const toggle = document.getElementById("notif-toggle");
  const dismissedNote = document.getElementById("dismissed-note");

  const { notificationsEnabled = true, dismissedSites = [] } =
    await browser.storage.local.get(["notificationsEnabled", "dismissedSites"]);

  toggle.checked = notificationsEnabled;
  toggle.addEventListener("change", () =>
    browser.storage.local.set({ notificationsEnabled: toggle.checked })
  );

  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  let hostname = null;
  try { hostname = new URL(tab.url).hostname.replace(/^www\./, ""); } catch {}

  const port = hostname && CATPPUCCIN_PORTS.find(p =>
    p.match.some(d => hostname === d || hostname.endsWith("." + d))
  );

  if (port) {
    const isDismissed = dismissedSites.includes(hostname);
    if (isDismissed) dismissedNote.style.display = "block";

    body.innerHTML = `
      <div class="match-card">
        <div class="label">Port available for this site</div>
        <div class="port-name">${port.name}</div>
        <div class="domain">${hostname}</div>
      </div>
      <div class="btn-row">
        <button class="btn btn-primary" id="btn-install">View on GitHub</button>
        <button class="btn btn-secondary" id="btn-mute">${isDismissed ? "Unmute site" : "Mute site"}</button>
      </div>
    `;

    document.getElementById("btn-install").addEventListener("click", () =>
      browser.tabs.create({ url: port.url })
    );

    document.getElementById("btn-mute").addEventListener("click", async () => {
      const { dismissedSites: cur = [] } = await browser.storage.local.get("dismissedSites");
      const updated = cur.includes(hostname)
        ? cur.filter(s => s !== hostname)
        : [...cur, hostname];
      await browser.storage.local.set({ dismissedSites: updated });
      window.close();
    });
  }
}

init();
