// ports.js loaded first via manifest.json
const notifiedTabs = new Map(); // tabId -> hostname

function getHostname(url) {
  try { return new URL(url).hostname.replace(/^www\./, ""); }
  catch { return null; }
}

function findPort(hostname) {
  return CATPPUCCIN_PORTS.find(p =>
    p.match.some(d => hostname === d || hostname.endsWith("." + d))
  ) || null;
}

browser.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab.url) return;

  const hostname = getHostname(tab.url);
  if (!hostname || notifiedTabs.get(tabId) === hostname) return;

  const port = findPort(hostname);
  if (!port) { notifiedTabs.delete(tabId); return; }

  notifiedTabs.set(tabId, hostname);

  const { notificationsEnabled = true, dismissedSites = [] } =
    await browser.storage.local.get(["notificationsEnabled", "dismissedSites"]);

  if (!notificationsEnabled || dismissedSites.includes(hostname)) return;

  browser.storage.local.set({ lastMatch: { port, hostname } });

  browser.notifications.create(`ctp-${tabId}`, {
    type: "basic",
    iconUrl: "icons/icon96.png",
    title: "Catppuccin port available!",
    message: `${port.name} has a userstyle. Click the toolbar icon to install it.`
  });
});

browser.tabs.onRemoved.addListener(tabId => notifiedTabs.delete(tabId));
