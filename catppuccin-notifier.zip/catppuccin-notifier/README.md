# 🐱 Catppuccin Port Notifier

A Firefox extension that notifies you whenever a [Catppuccin](https://catppuccin.com) userstyle is available for the website you're visiting.

## Features

- Desktop notification when you land on a site with a Catppuccin port
- Click the toolbar icon to see the port and open it on GitHub
- Mute notifications per-site
- Toggle notifications on/off globally
- Covers 100+ websites including GitHub, YouTube, Reddit, Discord, Twitch, and more

## Installation

### Temporary (for testing)
1. Open Firefox and go to `about:debugging`
2. Click **This Firefox** → **Load Temporary Add-on**
3. Navigate to this folder and select `manifest.json`

### Permanent (self-signed)
1. Install [web-ext](https://github.com/mozilla/web-ext): `npm install -g web-ext`
2. Run: `web-ext build` — this creates a `.zip` in `web-ext-artifacts/`
3. In Firefox go to `about:config` and set `xpinstall.signatures.required` to `false`
4. Go to `about:addons` → gear icon → **Install Add-on From File** → select the `.zip`

## How it works

The extension checks each page you visit against a list of known Catppuccin userstyles from [catppuccin/userstyles](https://github.com/catppuccin/userstyles). If there's a match, it shows a notification and lets you open the GitHub page for that port directly.

## Adding more ports

Edit `ports.js` and add an entry:
```js
{ name: "Site Name", url: "https://github.com/catppuccin/userstyles/...", match: ["example.com"] }
```

## License

MIT
