// No detection needed — background handles everything
